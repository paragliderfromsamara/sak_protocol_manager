-- MySQL dump 10.10
--
-- Host: localhost    Database: BD_Baraban
-- ------------------------------------------------------
-- Server version	5.0.21-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `BD_Baraban`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `bd_baraban` /*!40100 DEFAULT CHARACTER SET cp1251 */;

USE `BD_Baraban`;

--
-- Table structure for table `barabany`
--

DROP TABLE IF EXISTS `barabany`;
CREATE TABLE `barabany` (
  `BarabanInd` int(10) unsigned NOT NULL auto_increment,
  `TipInd` int(10) unsigned default NULL,
  `BarabanNum` tinytext,
  PRIMARY KEY  (`BarabanInd`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `barabany`
--


/*!40000 ALTER TABLE `barabany` DISABLE KEYS */;
LOCK TABLES `barabany` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `barabany` ENABLE KEYS */;

--
-- Table structure for table `tipy_baraban`
--

DROP TABLE IF EXISTS `tipy_baraban`;
CREATE TABLE `tipy_baraban` (
  `TipInd` int(10) unsigned NOT NULL auto_increment,
  `TipName` tinytext,
  `Massa` float default NULL,
  PRIMARY KEY  (`TipInd`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `tipy_baraban`
--


/*!40000 ALTER TABLE `tipy_baraban` DISABLE KEYS */;
LOCK TABLES `tipy_baraban` WRITE;
INSERT INTO `tipy_baraban` VALUES (1,'8А П',39.29),(2,'8б П',40),(5,'8 П',35.71),(6,'10 П',43.52),(7,'10а П',61.46),(8,'12 П',104.43),(9,'12а П',114.75),(10,'12б П',120),(61,'18з',455.1),(12,'14а П',161.9),(13,'14б П',198),(14,'14д П',282),(15,'14г П',213.34),(16,'16 П',250.62),(17,'16а П',254),(18,'17 П',288.5),(19,'17а П',308.83),(20,'17б П',331.5),(23,'18 П',436.67),(24,'18а П',436.67),(25,'18б П',495),(26,'18в П',361),(27,'18г П',450),(65,'08 O',43),(35,'20 П',602.27),(36,'20а П',574.37),(37,'20б П',738.27),(38,'20в П',576.42),(59,'18е',405.1),(40,'22а П',795),(41,'22б П',867),(42,'Бухта',0),(46,'22в П',881),(47,'14 П',173.92),(60,'20 O',763),(57,'22 П',779.03),(58,'14 в П',185.7),(62,'17 О',367),(63,'16у П',250.62),(64,'18у П',353.85),(66,'08А О',51),(67,'08Б O',53.5),(68,'10 О',56),(69,'10А О',75),(70,'12 О',132),(71,'12А О',151),(72,'14 О',217),(73,'14Г О',266),(74,'17А О',390),(75,'18 О',535),(76,'18А О',606),(77,'20 О',763),(78,'20А О',725),(79,'20Б О',941),(80,'20В О',700),(81,'22 О',965),(85,'коробка',0),(84,'16 О',308);
UNLOCK TABLES;
/*!40000 ALTER TABLE `tipy_baraban` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

